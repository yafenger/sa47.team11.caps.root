package sa47.team11.caps.exception;

@SuppressWarnings("serial")
public class courseNotFound extends Exception {

	public courseNotFound() {
	}
	
	public courseNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public courseNotFound(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public courseNotFound(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public courseNotFound(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
}
